/* AIGYPT — Public landing page */

const LandingPage = ({ onOpenLogin }) => {
  return (
    <div className="page-enter">
      <Hero onOpenLogin={onOpenLogin}/>
      <BantuanSection/>
      <ToolsPreview/>
      <PromptPreview onOpenLogin={onOpenLogin}/>
      <AdaptiveTeaser/>
      <EthicsTeaser/>
      <JoinCTA onOpenLogin={onOpenLogin}/>
    </div>
  );
};

/* ---------------- HERO ---------------- */
const Hero = ({ onOpenLogin }) => (
  <section className="relative overflow-hidden pt-12 md:pt-20 pb-20 md:pb-28">
    <Blob color="rgba(139,92,246,0.4)" size={620} top={-200} right={-100}/>
    <Blob color="rgba(212,165,116,0.18)" size={500} top={200} left={-150}/>
    <div className="absolute top-0 right-0 w-[60%] h-[120%] opacity-20 pointer-events-none">
      <Arch className="w-full h-full" color="rgba(212,165,116,0.18)"/>
    </div>
    <div className="absolute inset-0 pattern-stars opacity-50 pointer-events-none"/>

    <div className="container-x relative">
      <div className="grid lg:grid-cols-12 gap-10 items-center">
        <div className="lg:col-span-7">
          <Reveal>
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full chip-glass text-xs">
              <span className="w-1.5 h-1.5 rounded-full bg-gold-400 shadow-[0_0_8px_rgba(212,165,116,0.8)]"/>
              <span className="text-ink-muted">Premium AI Learning Companion · </span>
              <span className="arabic text-gold-300 text-sm">للمصريين العائدين</span>
            </div>
          </Reveal>

          <WordReveal
            as="h1"
            text="Belajar lebih cerdas di Mesir, dengan AI yang paham kamu."
            className="mt-6 font-display text-5xl sm:text-6xl md:text-7xl lg:text-[80px] font-semibold text-ink leading-[1.0] tracking-tightest"
          />

          <Reveal delay={300}>
            <p className="mt-6 text-lg md:text-xl text-ink-muted leading-relaxed max-w-2xl">
              Panduan Belajar dengan AI untuk Masisir.
              Memahami materi lebih cepat, mengerjakan tugas lebih cerdas, dan menemukan AI yang relevan
              untuk kehidupan akademik di Mesir.
            </p>
          </Reveal>

          <Reveal delay={500}>
            <div className="mt-9 flex flex-wrap items-center gap-3">
              <a href="#join" onClick={(e)=>{e.preventDefault(); const el = document.getElementById("join"); if (el) el.scrollIntoView({behavior:"smooth"});}} className="btn btn-primary text-base px-6 py-3.5">
                <Icon name="sparkles" className="w-4 h-4"/> Gabung Member
              </a>
              <a href="#preview" onClick={(e)=>{e.preventDefault(); const el = document.getElementById("preview"); if (el) el.scrollIntoView({behavior:"smooth"});}} className="btn btn-ghost text-base px-6 py-3.5">
                <Icon name="bookOpen" className="w-4 h-4"/> Lihat Preview
              </a>
              <button onClick={onOpenLogin} className="text-sm text-ink-muted hover:text-ink ml-2 underline underline-offset-4">
                Sudah punya kode?
              </button>
            </div>
          </Reveal>

          <Reveal delay={650}>
            <div className="mt-12 grid grid-cols-3 max-w-md gap-6">
              <div>
                <div className="font-display text-3xl text-gold-400 font-semibold num">6</div>
                <div className="text-xs text-ink-muted uppercase tracking-wider mt-1">AI Tools</div>
              </div>
              <div>
                <div className="font-display text-3xl text-gold-400 font-semibold num">36</div>
                <div className="text-xs text-ink-muted uppercase tracking-wider mt-1">Adaptive Guides</div>
              </div>
              <div>
                <div className="font-display text-3xl text-gold-400 font-semibold num">3</div>
                <div className="text-xs text-ink-muted uppercase tracking-wider mt-1">Learning Paths</div>
              </div>
            </div>
          </Reveal>
        </div>

        <div className="lg:col-span-5 hidden lg:block">
          <Reveal delay={300}>
            <HeroComposition/>
          </Reveal>
        </div>
      </div>
    </div>
    <div className="divider-arabesque mt-4"/>
  </section>
);

/* Hero composition: stylized dashboard preview */
const HeroComposition = () => (
  <div className="relative h-[480px]">
    {/* Dashboard glass card */}
    <div className="absolute inset-x-0 top-4 card-glass-strong p-6 shadow-glass" style={{transform: "perspective(900px) rotateY(-4deg) rotateX(2deg)"}}>
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-2">
          <LogoMark size={28}/>
          <span className="font-display text-sm text-ink font-medium">Dashboard</span>
        </div>
        <span className="chip chip-violet text-[10px]">🌙 Member</span>
      </div>
      <div className="arabic text-right text-lg text-gold-300 mb-4">السلام عليكم يا أحمد</div>
      <div className="text-xs uppercase tracking-wider text-ink-muted mb-3">AI rekomendasi untukmu</div>
      <div className="space-y-2">
        {[
          { n: "Claude", c: "#D97757", r: "Untuk bedah kitab klasik" },
          { n: "ChatGPT", c: "#10A37F", r: "Untuk diskusi bertahap" },
          { n: "Perplexity", c: "#1FB6B6", r: "Untuk riset referensi" },
        ].map((t, i) => (
          <div key={i} className="flex items-center gap-3 p-2.5 rounded-lg bg-white/4 border border-line">
            <span className="w-8 h-8 rounded-md flex items-center justify-center text-[10px] font-mono font-bold text-white" style={{background: t.c}}>{t.n.slice(0,2)}</span>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium text-ink">{t.n}</div>
              <div className="text-[11px] text-ink-muted truncate">{t.r}</div>
            </div>
            <Icon name="arrowRight" className="w-3.5 h-3.5 text-ink-soft"/>
          </div>
        ))}
      </div>
      <div className="mt-4 pt-4 border-t border-line">
        <div className="flex items-center justify-between text-xs">
          <span className="text-ink-muted">Progress · Bertumbuh</span>
          <span className="text-gold-400 font-medium num">42%</span>
        </div>
        <div className="mt-2 h-1.5 bg-white/5 rounded-full overflow-hidden">
          <div className="h-full bg-gradient-to-r from-violet-500 to-gold-500" style={{width: "42%"}}/>
        </div>
      </div>
    </div>
    {/* Floating member code chip */}
    <div className="absolute bottom-4 -left-4 card-glass p-3.5 shadow-glow" style={{transform: "rotate(-5deg)"}}>
      <div className="text-[10px] uppercase tracking-wider text-ink-muted mb-1">Kode Akses</div>
      <div className="font-mono text-base text-gold-300 tracking-widest">MSR-H82M-X4ZT</div>
    </div>
  </div>
);

/* ---------------- BANTUAN ---------------- */
const BantuanSection = () => (
  <section id="preview" className="section">
    <div className="container-x">
      <Reveal className="text-center max-w-2xl mx-auto mb-14">
        <div className="text-xs uppercase tracking-[0.22em] text-gold-400 mb-4 flex items-center justify-center gap-2">
          <span className="w-6 h-px bg-gold-500/70"/>Apa yang bisa dibantu?<span className="w-6 h-px bg-gold-500/70"/>
        </div>
        <h2 className="font-display text-4xl md:text-5xl font-semibold text-ink leading-[1.05]">
          Lima area belajar yang paling sering jadi tantangan Masisir.
        </h2>
      </Reveal>
      <Reveal stagger className="grid sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {STRUGGLES.map((s) => (
          <div key={s.id} className="card-glass p-6 hov-lift">
            <div className="w-11 h-11 rounded-lg bg-violet-500/15 text-violet-300 flex items-center justify-center mb-4">
              <Icon name={s.icon} className="w-5 h-5"/>
            </div>
            <h3 className="font-display text-xl font-semibold text-ink mb-2">{s.label}</h3>
            <p className="text-sm text-ink-muted leading-relaxed">{s.desc}</p>
          </div>
        ))}
      </Reveal>
    </div>
  </section>
);

/* ---------------- TOOLS PREVIEW ---------------- */
const ToolsPreview = () => (
  <section id="tools" className="section pt-0">
    <div className="container-x">
      <Reveal className="mb-12 flex items-end justify-between flex-wrap gap-6">
        <div>
          <div className="text-xs uppercase tracking-[0.22em] text-gold-400 mb-4 flex items-center gap-2">
            <span className="w-6 h-px bg-gold-500/70"/>AI Tools
          </div>
          <h2 className="font-display text-4xl md:text-5xl font-semibold text-ink leading-[1.05] max-w-2xl">
            Enam AI terbaik, dipilih untuk kebutuhan Masisir.
          </h2>
        </div>
        <span className="chip chip-glass">🔒 Adaptive guide unlock member</span>
      </Reveal>
      <Reveal stagger className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {AI_TOOLS.map((tool) => (
          <div key={tool.id} className="card-glass p-6 hov-lift">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <span className="w-11 h-11 rounded-xl flex items-center justify-center text-xs font-mono font-bold text-white shadow-lg" style={{background: tool.color}}>{tool.monogram}</span>
                <div>
                  <div className="font-display text-lg font-semibold text-ink">{tool.name}</div>
                  <div className="text-[11px] text-ink-soft">{tool.by}</div>
                </div>
              </div>
              <span className="chip chip-glass text-[10px]">{tool.tier}</span>
            </div>
            <p className="text-sm text-ink-muted leading-relaxed mb-4 clamp-3">{tool.description}</p>
            <div className="flex flex-wrap gap-1.5">
              {tool.bestAt.map((b, i) => (
                <span key={i} className="text-[11px] px-2 py-0.5 rounded bg-white/5 text-ink-muted border border-line">{b}</span>
              ))}
            </div>
          </div>
        ))}
      </Reveal>
    </div>
  </section>
);

/* ---------------- PROMPT PREVIEW (locked) ---------------- */
const PromptPreview = ({ onOpenLogin }) => (
  <section className="section pt-0">
    <div className="container-x">
      <Reveal className="mb-12">
        <div className="text-xs uppercase tracking-[0.22em] text-gold-400 mb-4 flex items-center gap-2">
          <span className="w-6 h-px bg-gold-500/70"/>Adaptive Tool Guides
        </div>
        <h2 className="font-display text-4xl md:text-5xl font-semibold text-ink leading-[1.05] max-w-3xl">
          Cara pakai AI yang menyesuaikan <em className="text-gold-300 not-italic">cara belajarmu</em>.
        </h2>
        <p className="mt-4 text-ink-muted text-lg max-w-2xl">
          Bukan tutorial generik. Setiap guide otomatis adaptif — same AI, beda gaya belajar, beda workflow.
        </p>
      </Reveal>
      <div className="relative">
        <Reveal className="locked-preview">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {LEARNING_STYLES.slice(0, 6).map((style, i) => (
              <div key={style.id} className="card-glass p-5">
                <div className="flex items-center gap-2 mb-3">
                  <span className="text-2xl">{style.emoji}</span>
                  <span className="font-display text-base font-semibold text-ink">{style.label}</span>
                </div>
                <div className="text-xs uppercase tracking-wider text-gold-400 mb-2">Cara Mulai · ChatGPT</div>
                <ol className="text-sm text-ink-muted leading-relaxed space-y-1.5 list-decimal pl-4">
                  <li>Buka ChatGPT, mulai dengan konteks "saya mahasiswa Azhar..."</li>
                  <li>Pakai pendekatan {style.label.toLowerCase()} sebagai gaya percakapan.</li>
                  <li>Tutup sesi dengan minta ringkasan 5 poin.</li>
                </ol>
                <div className="mt-4 pt-3 border-t border-line">
                  <div className="font-mono text-[11px] text-violet-200/80 clamp-2">"Saya mahasiswa Azhar. Pakai pendekatan {style.label.toLowerCase()} untuk membantu..."</div>
                </div>
              </div>
            ))}
          </div>
        </Reveal>
        <div className="absolute inset-0 locked-overlay flex items-end justify-center pb-12 pointer-events-none">
          <div className="pointer-events-auto text-center max-w-md">
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-full chip-gold mb-4">
              <Icon name="bookmark" className="w-6 h-6"/>
            </div>
            <h3 className="font-display text-2xl font-semibold text-ink mb-2">Akses Penuh untuk Member</h3>
            <p className="text-sm text-ink-muted mb-5">36 adaptive guide (6 AI × 6 gaya belajar) — semua workflow lengkap dengan starter prompt.</p>
            <button onClick={onOpenLogin} className="btn btn-gold">
              <Icon name="user" className="w-4 h-4"/> Login Member
            </button>
          </div>
        </div>
      </div>
    </div>
  </section>
);

/* ---------------- ADAPTIVE TEASER ---------------- */
const AdaptiveTeaser = () => (
  <section className="section pt-0">
    <div className="container-x">
      <div className="card-glass-strong p-10 md:p-14 relative overflow-hidden">
        <Blob color="rgba(212,165,116,0.25)" size={400} top={-100} right={-100}/>
        <Blob color="rgba(139,92,246,0.3)" size={300} bottom={-50} left={-50}/>
        <div className="relative grid md:grid-cols-12 gap-8 items-center">
          <div className="md:col-span-7">
            <div className="text-xs uppercase tracking-[0.22em] text-gold-400 mb-4">Adaptive Engine</div>
            <h2 className="font-display text-3xl md:text-4xl font-semibold text-ink leading-tight mb-5">
              Same AI, different guide — sesuai gaya belajarmu.
            </h2>
            <p className="text-ink-muted text-lg leading-relaxed max-w-xl mb-6">
              ChatGPT untuk pendiskusi ≠ ChatGPT untuk penghafal. Setelah onboarding singkat,
              kamu langsung dapat panduan yang relevan untuk caramu belajar.
            </p>
            <div className="grid grid-cols-3 gap-3 max-w-md">
              {[
                { l: "Diskusi", c: "violet" },
                { l: "Hafalan", c: "gold" },
                { l: "Visual", c: "violet" },
              ].map((c, i) => (
                <div key={i} className={`p-3 rounded-lg border ${c.c === "gold" ? "bg-gold-500/8 border-gold-500/25" : "bg-violet-500/8 border-violet-500/25"}`}>
                  <div className={`text-xs uppercase tracking-wider ${c.c === "gold" ? "text-gold-300" : "text-violet-300"}`}>ChatGPT</div>
                  <div className="text-sm text-ink mt-0.5 font-medium">{c.l} mode</div>
                </div>
              ))}
            </div>
          </div>
          <div className="md:col-span-5">
            <div className="relative">
              <div className="absolute inset-x-0 top-0 card-glass p-4 shadow-glass" style={{transform:"rotate(-2deg) translateY(0)"}}>
                <div className="flex items-center gap-2 mb-2">
                  <span className="w-7 h-7 rounded-md bg-violet-500 text-white text-[10px] font-bold flex items-center justify-center">GPT</span>
                  <span className="text-xs text-ink-muted">→ Diskusi</span>
                </div>
                <p className="font-mono text-xs text-ink-muted leading-relaxed clamp-3">"Jangan beri jawaban langsung — tanyakan dulu apa yang sudah aku tahu..."</p>
              </div>
              <div className="absolute inset-x-0 top-24 card-glass p-4 shadow-glow" style={{transform:"rotate(1deg)"}}>
                <div className="flex items-center gap-2 mb-2">
                  <span className="w-7 h-7 rounded-md bg-violet-500 text-white text-[10px] font-bold flex items-center justify-center">GPT</span>
                  <span className="text-xs text-ink-muted">→ Hafalan</span>
                </div>
                <p className="font-mono text-xs text-ink-muted leading-relaxed clamp-3">"Sesi tasmi' — sebut potongan ayat, aku lanjutkan. Beri 3 huruf petunjuk jika ragu..."</p>
              </div>
              <div className="absolute inset-x-0 top-48 card-glass p-4 shadow-glass" style={{transform:"rotate(-1deg)"}}>
                <div className="flex items-center gap-2 mb-2">
                  <span className="w-7 h-7 rounded-md bg-violet-500 text-white text-[10px] font-bold flex items-center justify-center">GPT</span>
                  <span className="text-xs text-ink-muted">→ Visual</span>
                </div>
                <p className="font-mono text-xs text-ink-muted leading-relaxed clamp-3">"Buatkan peta konsep berjenjang: akar → cabang → daun..."</p>
              </div>
              <div className="h-72"/>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

/* ---------------- ETHICS TEASER ---------------- */
const EthicsTeaser = () => (
  <section className="section pt-0">
    <div className="container-x">
      <Reveal className="grid md:grid-cols-12 gap-8 items-center card-glass p-8 md:p-12 relative overflow-hidden">
        <div className="absolute top-0 right-0 h-full w-1/2 opacity-20 pointer-events-none">
          <Arch className="w-full h-full" color="rgba(212,165,116,0.25)"/>
        </div>
        <div className="md:col-span-7 relative">
          <div className="text-xs uppercase tracking-[0.22em] text-gold-400 mb-4">Adab Thalabul Ilmi</div>
          <h2 className="font-display text-3xl md:text-4xl font-semibold text-ink leading-tight mb-5">
            AI yang dipakai dengan adab — bukan menggantikan tafahhum.
          </h2>
          <p className="text-ink-muted text-lg leading-relaxed mb-5">
            Setiap rekomendasi & guide kami menekankan: AI adalah wasilah, bukan tujuan.
            Kamu tetap thalibul ilmi — AI cuma alat untuk lebih dalam, bukan lebih malas.
          </p>
          <a href="#/ethics" onClick={(e)=>{e.preventDefault(); navigate("/ethics");}} className="btn btn-ghost">
            Baca Etika & Adab <Icon name="arrowRight" className="w-4 h-4"/>
          </a>
        </div>
        <div className="md:col-span-5 relative">
          <div className="card-glass-strong p-7 text-center">
            <Icon name="quote" className="w-7 h-7 text-gold-400 mx-auto mb-4" strokeWidth={1.4}/>
            <div className="arabic text-2xl text-gold-200 leading-loose mb-3">إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ</div>
            <p className="text-sm text-ink-muted italic">"Sesungguhnya amal itu tergantung niatnya."</p>
            <div className="text-xs text-ink-soft tracking-wider mt-2">— HR. Bukhari & Muslim</div>
          </div>
        </div>
      </Reveal>
    </div>
  </section>
);

/* ---------------- JOIN CTA ---------------- */
const JoinCTA = ({ onOpenLogin }) => (
  <section id="join" className="section pt-0">
    <div className="container-x">
      <div className="rounded-3xl card-glass-strong shadow-glass p-10 md:p-16 relative overflow-hidden">
        <Blob color="rgba(139,92,246,0.5)" size={500} top={-200} right={-100}/>
        <Blob color="rgba(212,165,116,0.3)" size={400} bottom={-100} left={-100}/>
        <div className="relative text-center max-w-2xl mx-auto">
          <div className="arabic text-2xl text-gold-300 mb-4">رَبِّ زِدْنِي عِلْمًا</div>
          <h3 className="font-display text-3xl md:text-5xl font-semibold leading-tight gradient-text mb-5">
            AI learning companion premium untukmu.
          </h3>
          <p className="text-ink-muted text-lg leading-relaxed mb-8">
            Dapatkan kode akses member dan mulai journey-mu — 3 pertanyaan onboarding,
            lalu dashboard personal langsung jalan.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3 mb-8">
            <a href="https://wa.me/201XXXXXXXXX" target="_blank" rel="noreferrer" className="btn btn-gold text-base px-6 py-3.5">
              <Icon name="messageSquare" className="w-4 h-4"/> Hubungi WhatsApp
            </a>
            <button onClick={onOpenLogin} className="btn btn-ghost text-base px-6 py-3.5">
              <Icon name="user" className="w-4 h-4"/> Sudah punya kode?
            </button>
          </div>
          <div className="grid sm:grid-cols-3 gap-3 max-w-md mx-auto pt-6 border-t border-line">
            {[
              { i: "check", t: "Onboarding 3 pertanyaan" },
              { i: "check", t: "Rekomendasi personal" },
              { i: "check", t: "Adaptive guide & path" },
            ].map((c, i) => (
              <div key={i} className="flex items-center gap-2 text-xs text-ink-muted justify-center sm:justify-start">
                <Icon name={c.i} className="w-3.5 h-3.5 text-mint-500" strokeWidth={2.4}/> {c.t}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  </section>
);

window.LandingPage = LandingPage;
