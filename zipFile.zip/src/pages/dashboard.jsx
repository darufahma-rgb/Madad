/* AIGYPT — Personal Dashboard */

const DashboardPage = () => {
  const { session, profile, progress, clearProfile, setLastActivity } = useAuth();

  // Hooks must run unconditionally — compute even when not logged in
  const recs = useMemo(() => profile ? recommend(profile) : [], [profile]);
  const stage = useMemo(() => computeStage(), [progress]);

  // Guards
  useEffect(() => {
    if (!session) { navigate("/"); return; }
    if (!profile?.onboarded) { navigate("/onboarding"); return; }
  }, [session, profile]);

  if (!session || !profile?.onboarded) return null;
  const styleLabel = profile.learningStyle?.[0]
    ? LEARNING_STYLES.find(s => s.id === profile.learningStyle[0])?.label
    : "campuran";
  const fieldLabel = FIELDS.find(f => f.id === profile.field)?.label || "—";

  const firstName = session.name.split(" ")[0];

  return (
    <div className="page-enter">
      {/* Hero greeting */}
      <section className="relative pt-12 md:pt-16 pb-8 overflow-hidden">
        <Blob color="rgba(139,92,246,0.25)" size={500} top={-200} right={-100}/>
        <div className="absolute inset-0 pattern-stars opacity-30 pointer-events-none"/>
        <div className="container-x relative">
          <Reveal>
            <div className="arabic text-2xl text-gold-300 mb-3">السلام عليكم</div>
            <h1 className="font-display text-4xl md:text-6xl font-semibold text-ink leading-[1.05] tracking-tightest">
              Assalamu'alaikum, <span className="gradient-text">{firstName}</span> 🌙
            </h1>
            <p className="mt-4 text-ink-muted text-lg max-w-2xl">
              Dashboard ini disusun berdasarkan profilmu — {styleLabel.toLowerCase()}, {fieldLabel.toLowerCase()}, dan area belajar yang kamu pilih.
            </p>
          </Reveal>
        </div>
      </section>

      {/* Continue learning + Stage */}
      <section className="pb-8">
        <div className="container-x">
          <Reveal className="grid md:grid-cols-12 gap-4">
            <ContinueCard className="md:col-span-8" progress={progress}/>
            <StageCard className="md:col-span-4" stage={stage}/>
          </Reveal>
        </div>
      </section>

      {/* AI recommendations */}
      <section className="pb-8">
        <div className="container-x">
          <Reveal className="mb-6 flex items-end justify-between flex-wrap gap-3">
            <div>
              <div className="text-xs uppercase tracking-[0.22em] text-gold-400 mb-3 flex items-center gap-2">
                <span className="w-6 h-px bg-gold-500/70"/>Rekomendasi untukmu
              </div>
              <h2 className="font-display text-3xl md:text-4xl font-semibold text-ink">AI yang paling cocok untukmu</h2>
            </div>
            <a href="#/tools" onClick={(e)=>{e.preventDefault(); navigate("/tools");}} className="text-sm text-violet-300 hover:text-violet-200 inline-flex items-center gap-1">
              Lihat semua adaptive guide <Icon name="arrowRight" className="w-3.5 h-3.5"/>
            </a>
          </Reveal>
          <Reveal stagger className="grid md:grid-cols-3 gap-4">
            {recs.map((rec, i) => <RecommendationCard key={rec.toolId} rec={rec} index={i} profile={profile}/>)}
          </Reveal>
        </div>
      </section>

      {/* Learning paths */}
      <section className="pb-8">
        <div className="container-x">
          <Reveal className="mb-6">
            <div className="text-xs uppercase tracking-[0.22em] text-gold-400 mb-3">Progress per Path</div>
            <h2 className="font-display text-3xl md:text-4xl font-semibold text-ink">Learning path</h2>
          </Reveal>
          <Reveal stagger className="grid md:grid-cols-3 gap-4">
            {LEARNING_PATHS.map((path) => {
              const pct = computePathProgress(path.id);
              return (
                <a key={path.id} href={"#/paths"} onClick={(e)=>{e.preventDefault(); navigate("/paths");}} className="card-glass p-6 hov-lift block">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <div className="text-2xl mb-2">{path.icon}</div>
                      <div className="text-[11px] uppercase tracking-wider text-gold-400">{path.level}</div>
                      <div className="font-display text-xl font-semibold text-ink mt-0.5">{path.label}</div>
                    </div>
                    <span className="text-xs text-ink-muted num">{pct}%</span>
                  </div>
                  <p className="text-sm text-ink-muted leading-relaxed clamp-2 mb-4">{path.desc}</p>
                  <div className="h-1.5 bg-white/5 rounded-full overflow-hidden mb-3">
                    <div className="h-full transition-all duration-700" style={{width: `${pct}%`, background: `linear-gradient(90deg, ${path.color}, #D4A574)`}}/>
                  </div>
                  <div className="flex items-center justify-between text-xs text-ink-muted">
                    <span>{path.modules.length} modul</span>
                    <span className="inline-flex items-center gap-1 text-violet-300">Mulai <Icon name="arrowRight" className="w-3 h-3"/></span>
                  </div>
                </a>
              );
            })}
          </Reveal>
        </div>
      </section>

      {/* Quick actions */}
      <section className="pb-16">
        <div className="container-x">
          <Reveal className="mb-6">
            <h2 className="font-display text-2xl md:text-3xl font-semibold text-ink">Aksi cepat</h2>
          </Reveal>
          <Reveal stagger className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <QuickAction icon="bookOpen" title="Buka tool guide" desc="Adaptive guide sesuai gaya belajarmu" to="/tools" color="violet"/>
            <QuickAction icon="layers" title="Mulai learning path" desc="Modul terstruktur 3 level" to="/paths" color="gold"/>
            <QuickAction icon="shield" title="Etika & Adab" desc="Pakai AI dengan benar" to="/ethics" color="violet"/>
            <QuickAction icon="refresh" title="Update profil" desc="Ubah jawaban onboarding" onClick={() => {
              if (confirm("Reset jawaban onboarding dan ulangi?")) {
                clearProfile();
                navigate("/onboarding");
              }
            }} color="gold"/>
          </Reveal>
        </div>
      </section>
    </div>
  );
};

const ContinueCard = ({ className = "", progress }) => {
  const last = progress?.lastActivity;
  if (!last) {
    return (
      <div className={`${className} card-glass-strong p-7 relative overflow-hidden`}>
        <div className="flex items-start gap-4">
          <span className="w-12 h-12 rounded-xl bg-gradient-to-br from-violet-500 to-violet-700 text-white flex items-center justify-center shadow-glow">
            <Icon name="sparkles" className="w-5 h-5"/>
          </span>
          <div className="flex-1">
            <div className="text-xs uppercase tracking-wider text-gold-400 mb-1">Mulai journey-mu</div>
            <div className="font-display text-xl text-ink font-semibold mb-2">Belum ada aktivitas terakhir</div>
            <p className="text-sm text-ink-muted mb-4">Mulai dari learning path Beginner atau langsung ke adaptive tool guide untuk AI yang direkomendasikan.</p>
            <div className="flex gap-2 flex-wrap">
              <a href="#/paths" onClick={(e)=>{e.preventDefault(); navigate("/paths");}} className="btn btn-primary text-sm py-2.5">
                Mulai Beginner <Icon name="arrowRight" className="w-4 h-4"/>
              </a>
              <a href="#/tools" onClick={(e)=>{e.preventDefault(); navigate("/tools");}} className="btn btn-ghost text-sm py-2.5">Buka Tool Guide</a>
            </div>
          </div>
        </div>
      </div>
    );
  }
  return (
    <div className={`${className} card-glass-strong p-7`}>
      <div className="flex items-center gap-2 mb-2">
        <span className="chip chip-violet text-[10px]">Continue Learning</span>
      </div>
      <div className="font-display text-2xl text-ink font-semibold mb-2">{last.label}</div>
      <p className="text-sm text-ink-muted mb-5">Terakhir kamu belajar tentang ini. Lanjut di mana kamu berhenti.</p>
      <a href={`#/paths`} onClick={(e)=>{e.preventDefault(); navigate("/paths");}} className="btn btn-gold text-sm py-2.5">
        Lanjutkan <Icon name="arrowRight" className="w-4 h-4"/>
      </a>
    </div>
  );
};

const StageCard = ({ className = "", stage }) => (
  <div className={`${className} card-glass p-7 relative overflow-hidden`}>
    <div className="absolute -top-8 -right-8 w-32 h-32 rounded-full opacity-30" style={{background: "radial-gradient(circle, #D4A574, transparent 60%)"}}/>
    <div className="relative">
      <div className="text-xs uppercase tracking-wider text-gold-400 mb-2">Tahap belajarmu</div>
      <div className="flex items-baseline gap-3 mb-1">
        <div className="text-4xl">{stage.icon}</div>
        <div className="font-display text-2xl font-semibold text-ink">{stage.label}</div>
      </div>
      <p className="text-xs text-ink-muted leading-relaxed">
        {stage.id === "starting" && "Baru mulai — fokus dulu di learning path Beginner."}
        {stage.id === "growing" && "Sudah berkembang — lanjut ke level Intermediate untuk workflow yang lebih dalam."}
        {stage.id === "ready" && "AI-ready — kamu siap pakai multi-AI workflow untuk riset advanced."}
      </p>
    </div>
  </div>
);

const RecommendationCard = ({ rec, index, profile }) => {
  const { tool, reason } = rec;
  const primaryStyle = profile.learningStyle?.[0];
  const styleLabel = primaryStyle ? LEARNING_STYLES.find(s => s.id === primaryStyle)?.label : null;
  return (
    <div className="card-glass-strong p-6 hov-lift flex flex-col relative overflow-hidden">
      <div className="absolute top-0 right-0 w-24 h-24 opacity-30 pointer-events-none" style={{background: `radial-gradient(circle at top right, ${tool.color}, transparent 70%)`}}/>
      <div className="relative flex-1 flex flex-col">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <span className="w-12 h-12 rounded-xl flex items-center justify-center text-sm font-mono font-bold text-white shadow-lg" style={{background: tool.color}}>{tool.monogram}</span>
            <div>
              <div className="font-display text-xl font-semibold text-ink">{tool.name}</div>
              <div className="text-[11px] text-ink-soft">{tool.by}</div>
            </div>
          </div>
          {index === 0 && <span className="chip chip-gold text-[10px]">✨ Top pick</span>}
        </div>

        <div className="mb-4">
          <div className="text-[11px] uppercase tracking-wider text-gold-400 font-semibold mb-1.5">Kenapa untukmu</div>
          <p className="text-sm text-ink-muted leading-relaxed">
            Cocok karena kamu pilih <span className="text-ink">{styleLabel ? styleLabel.toLowerCase() : "campuran gaya"}</span> & {reason}.
          </p>
        </div>

        <div className="mb-5">
          <div className="text-[11px] uppercase tracking-wider text-ink-muted mb-1.5">Paling jago di</div>
          <div className="flex flex-wrap gap-1.5">
            {tool.bestAt.map((b, i) => <span key={i} className="text-[11px] px-2 py-0.5 rounded bg-white/5 text-ink-muted border border-line">{b}</span>)}
          </div>
        </div>

        <div className="mt-auto flex items-center gap-2 pt-4 border-t border-line">
          <a href={tool.link} target="_blank" rel="noreferrer" className="btn btn-primary text-sm py-2.5 flex-1">
            Buka {tool.name} <Icon name="arrowRight" className="w-4 h-4"/>
          </a>
          <a href={`#/tools?id=${tool.id}`} onClick={(e)=>{e.preventDefault(); navigate(`/tools?id=${tool.id}`);}} className="btn btn-ghost text-sm py-2.5 px-3">
            <Icon name="sparkles" className="w-4 h-4"/>
          </a>
        </div>
        <a href={`#/tools?id=${tool.id}`} onClick={(e)=>{e.preventDefault(); navigate(`/tools?id=${tool.id}`);}} className="mt-2 text-xs text-violet-300 hover:text-violet-200 text-center">
          ✨ Tunjukkan cara mulai
        </a>
      </div>
    </div>
  );
};

const QuickAction = ({ icon, title, desc, to, onClick, color = "violet" }) => {
  const handle = (e) => {
    e.preventDefault();
    if (onClick) onClick();
    else if (to) navigate(to);
  };
  return (
    <a href={to ? "#" + to : "#"} onClick={handle} className="card-glass p-5 hov-lift block">
      <div className={`w-10 h-10 rounded-lg flex items-center justify-center mb-3 ${color === "gold" ? "bg-gold-500/15 text-gold-300" : "bg-violet-500/15 text-violet-300"}`}>
        <Icon name={icon} className="w-5 h-5"/>
      </div>
      <div className="font-display text-base font-semibold text-ink mb-1">{title}</div>
      <p className="text-xs text-ink-muted leading-relaxed">{desc}</p>
    </a>
  );
};

window.DashboardPage = DashboardPage;
