/* AIGYPT — App shell + routing */

const App = () => {
  const path = useRoute();
  const { session, profile } = useAuth();
  const [loginOpen, setLoginOpen] = useState(false);

  // Auto-redirect logic on path change
  useEffect(() => {
    // Member-only routes
    const memberOnly = ["/dashboard", "/tools", "/paths", "/onboarding"];
    const isMemberRoute = memberOnly.some(r => path === r || path.startsWith(r + "?") || path.startsWith(r + "/"));
    if (isMemberRoute && !session) {
      navigate("/");
      setTimeout(() => setLoginOpen(true), 100);
      return;
    }
    // If logged in & on landing, suggest dashboard (don't force — landing useful for reviewing content)
    // If member without profile and tries dashboard/tools/paths → redirect to onboarding
    if (session && profile && !profile.onboarded) {
      if (path === "/dashboard" || path.startsWith("/tools") || path === "/paths") {
        navigate("/onboarding");
      }
    }
  }, [path, session, profile]);

  const handleLoginSuccess = (result) => {
    setLoginOpen(false);
    const p = getProfile();
    if (!p?.onboarded) navigate("/onboarding");
    else navigate("/dashboard");
  };

  const isAdmin = path === "/admin" || path.startsWith("/admin/");

  // Admin gets its own layout (no public nav/footer)
  if (isAdmin) {
    return (
      <ToastProvider>
        <div data-screen-label="Admin">
          <AdminPage/>
        </div>
      </ToastProvider>
    );
  }

  let routeLabel = "Beranda";
  let page = <LandingPage onOpenLogin={() => setLoginOpen(true)}/>;
  if (path === "/ethics")            { page = <EthicsPage/>; routeLabel = "Etika"; }
  else if (path === "/onboarding")   { page = <OnboardingPage/>; routeLabel = "Onboarding"; }
  else if (path === "/dashboard")    { page = <DashboardPage/>; routeLabel = "Dashboard"; }
  else if (path.startsWith("/tools")) { page = <ToolGuidePage/>; routeLabel = "Tool Guide"; }
  else if (path === "/paths")        { page = <PathsPage/>; routeLabel = "Learning Path"; }

  return (
    <ToastProvider>
      <div data-screen-label={routeLabel} className="min-h-screen flex flex-col">
        <Navbar onOpenLogin={() => setLoginOpen(true)}/>
        <main className="flex-1">
          {page}
        </main>
        <Footer/>
      </div>
      <LoginModal open={loginOpen} onClose={() => setLoginOpen(false)} onSuccess={handleLoginSuccess}/>
    </ToastProvider>
  );
};

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App/>);
